<?php

namespace xiling;
//没有命名空间的话且载入10.php new shua()会报错,因为不允许类重名
include './10.php';
class shua{
	public function __construct(){
		echo 'ss';
	}
}
new shua();//ss,优先找本文件的shua()
new \xi\shua();//good，即使载入了也必须指定路径

use xi\shua as dd;
new dd();//good

use xi\hua as hh;//常用的作为as
new hh();//ood

use xi\hua;
new hua();//ood,等于new xi\hua()



//namespace是可以一层一层类似于文件夹一样设置的如 
//namespace wang\keyi\de  
?>