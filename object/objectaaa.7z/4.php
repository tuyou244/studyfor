<?php

/*
$dd=rand(100, 200);
$ee=mt_rand(100, 200);
echo $dd;
echo $ee;
*/

//单例模式
//1
//class single{
//	public $rand;
//	public function __construct(){
//	echo 	$this->rand=mt_rand(10000000, 99999999);
//	}
//}
//$a=new single();

//var_dump(new single());
//var_dump(new single());

//2
//class single{
//	public $rand;
//	protected function __construct(){
//		$this->rand=mt_rand(10000000, 99999999);
//	}
//}
//
//var_dump(new single());
//var_dump(new single());


//3
//class single{
//	public $rand;
//	protected function __construct(){
//		$this->rand=mt_rand(10000000, 99999999);
//	}
//	public 
//}
//
//var_dump(new single());
//var_dump(new single());

class single{
	public $rand;
	static public $ob;
	final protected function __construct(){
		echo  $this->rand=mt_rand(100000, 999999);
	}
	static public function getins(){
		if(single::$ob===null){
		single::$ob=new single();
	}
		return single::$ob;
	}
}
//
//class ss extends single{
//	public function __construct(){
//		var_dump(rand(111111, 999999));
//	}
//}
//new single();
//echo '<br>';
//new single();
var_dump(single::getins());
var_dump(single::getins());
//$yy=new ss();
//$yy=new ss();

?>