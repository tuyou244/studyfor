<?php

function myload($lass){
	require './'.$lass.'.class.php';
}

spl_autoload_register('myload');

new mysqoo();



?>