<?php

class Test{
	//方法
public	function fly(){
		echo 'claa1test';
	}
	
	//属性
public	$name = 'zhangsan';

//public $sum = rand(10, 100);//错误
public $sum = 10-100;
public $su = 0||2;
public $suaa = array('1'=>array('b'=>'goodjob'));
//public $aaa = ['a'=>['b'=>'22ss']];
public $aaa = ['a'=>'22ss','c'=>233,'d'=>'233'];
}

$test = new Test();
$test->fly();
echo $test->name;
echo '<br>';
echo $test->su;
print_r($test->suaa);
//print_r($test->aaa);
var_dump($test->aaa);


//类与对象的关系
class A{
	public $name='wang';
	public $age = '22';
	public function career(){
		echo '最强';
	}
}

$qwe=new A();
echo $qwe->name;//wang
echo '<br>';
$qwe->name='junjin';
echo $qwe->name;//junjin
$qwe->career();//最强

//this
class ren{
	public $name = 'lisi';
	public function fly(){
		echo $this->name.'qifei';
	}
}

$ren = new ren();
echo '<br>';
$ren->name='ss';
echo '<br>';
$ren->fly();//$this->name.'qifei'   ssqifei  被拼接的
//$ren->fly();//$this->name='qifei'   qifei  


//封装数据库的类
class MYSQL{
	public $link;
	//连接数据库的函数
	public function conn(){
		$cfg = array(
		'host'=>'localhost',
		'user'=>'root',
		'password'=>'root',
		'db'=>'blog',
		'charset'=>'utf8'
		);
		$a=$this->link=mysqli_connect($cfg['host'], $cfg['user'], $cfg['password'], $cfg['db']);
		var_dump($a);
	}
	
//执行sql语句
public function query($sql){
	return mysqli_query($this->link, $sql);
}	
	
//获取数据库的数据
public function getAll($sql){
	$rs = $this->query($sql);
	$data = array();
	while($row = mysqli_fetch_assoc($rs)){
		$data[]=$row;
	}
	
	return $data;
}	

}//数据库的类结束

$db = new MYSQL();
$db->conn();
$a = $db->getAll('select * from cat');
var_dump($a);


?>