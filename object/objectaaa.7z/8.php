<?php
//抽象类


//abstract class adb{
//	abstract public function fly($a,$b);
//	abstract public function swim($a,$b);
//}
//
//class a extends adb{
//	
//}

//
////接口
//interface flyer{
//	public function flyer($a);
//}
//interface swim{
//	public function swim($a);
//}
//interface land{
//	public function land($a);
//}
//
//class dd implements flyer,swim,land{
//	public function swim($a){
//		echo 'i can swim';
//	}
//	public function flyer($a){
//		echo 'i can fly';
//	}
//	public function land($a){
//		echo 'i can land';
//	}
//}
//
//$dd = new dd();
//$dd->flyer('aa');

function t1(){
	if(rand(1, 10)>5){
		throw new Exception("huaile", 1);
		 
	}else{
		return t2();
	}
}
function t2(){
	if(rand(1, 10)>5){
		throw new Exception("aile", 2);
	}else{
		return t3();
	}
}
function t3(){
	if(rand(1, 10)>5){
		throw new Exception("uale", 3);
	}else{
		return true;
	}
}
try{
var_dump(t1());
}catch(Exception $e){
//	var_dump($e);
	echo $e->getFile();//对象调用方法
	echo $e->getLine();
	echo $e->getMessage();
	echo $e->getCode();
}//throw 抛出异常，try触发异常，catch接收异常//$e为异常,是个对象


?>