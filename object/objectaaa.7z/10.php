<?php
namespace xi;
class shua{
	public function __construct(){
		echo 'good';
	}
}

class hua{
	public function __construct(){
		echo 'ood';
	}
}
?>