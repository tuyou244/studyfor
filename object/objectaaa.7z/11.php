<?php
class par{
	public function a(){
		echo 'a';
	}
	public function b(){
		$this->a();
	}
}

class son extends par{
	public function a(){
		echo 'c';
	}
}

$err= new son();
$err->b();//实例化的是c



//若不必实例化
class are{
static	public function a(){
		echo 'a';
	}
static	public function b(){
		self::a();
	}
}

class suon extends are{
	static public function a(){
		echo 'c';
	}
}
suon::b();//a

//若不必实例化的延迟绑定，符合生活逻辑
class re{
static	public function a(){
		echo 'a';
	}
static	public function b(){
		static::a();
	}
}

class sun extends re{
	static public function a(){
		echo 'c';
	}
}
sun::b();//c

//既然子类已经修改 ，应该用子类//实例化或者延迟绑定


//static 超载


//多态
class car{
}

class bmw extends car{
	public function run(){
		echo 'bwhhhhhh';
	}
}

function drive($car){
	$car->run();//$car必须是对象
}
drive(new bmw);
drive(new bmw());//此处加不加括号都可以

?>