<?php
//$this self parent
class single{
	public $rand;
	static public $ob;
	final protected function __construct(){
		echo  $this->rand=mt_rand(100000, 999999);
	}
	static public function getins(){
		if(self::$ob===null){
		self::$ob=new self();
	}
		return self::$ob;
	}
}

var_dump(single::getins());

class par{
	public  function __construct(){
		echo rand(11111, 99999);
	}
}
class son extends par{
	public function __construct(){
		parent::__construct();
		echo 'haodeba';
	}
}
new son();
new son();
?>