<?php
class mysqoo{
	
}
?>