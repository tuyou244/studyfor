<?php

//类的封装性，禁止外部调用，使用protected

class ATM{
//	public function getPwd(){
//		return '123456';
//	}
	protected function getPwd(){
		return '123456';
	}
	public function checkPwd($pwd){
		return $this->getPwd()===$pwd;
	}
}

$atm = new ATM();
//echo $atm->getPwd();
//echo $atm->checkPwd('123456');//正确则为1，错误则不显示
echo $atm->checkPwd('123456');//


//类的继承性

class Good{
	public function aa(){
		echo 'aa';
	}
	public function bb(){
		echo 'bb';
	}
}
class bad extends Good{
	public function aa(){
		echo '替换掉了';
	}
	public function dd(){
		 $this->bb();
	}
}

$as =new bad();
$as->aa();//替换掉了
$as->bb();//bb
$as->dd();//bb
/*
//final 
class po{
	final public function ss(){
		echo 'ss';
	}
}
class qa extends po{
	public function ss(){
		echo 'gggg';//final方法不能被重写
	}
}
$qa = new qa();
//$qa->ss();//final方法可以被调用，但不能被重写
*/

//三种权限
class HUMAN{
	public $money=2000;
	public function t1(){
		echo $this->money;
	}
}
class SD extends HUMAN{
	
}
$HUMAN=new HUMAN();
echo $HUMAN->money;//2000
$HUMAN->t1();//2000
echo $HUMAN->money=3000;//3000
$HUMAN->t1();//3000,若没有前面的money=3000则依旧是2000

class Math{
	static public $name='lisi';
	 static public  function add($a,$b){
		return $a+$b;
	}
}

echo Math::add(1,2);
echo Math::$name;


define('PO', '123456');
define('PU', 123456);
echo PO;//123456
echo PU;//123456
var_dump(PU);//int(123456)
var_dump(PO);// string(6) "123456"

class ok{
	const PI=123;
	static public function fly(){
//		echo ok::PI;
		return ok::PI;
	}
}

$nn=new ok();
$nn->fly();//123

//ok::fly();//123

echo ok::fly();//123

?>