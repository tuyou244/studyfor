<?php

abstract class aDB {
/**
* 
*/
abstract public function conn();
/**
* 􀝎􁭆query􀺱􁧃
* @param string $sql sql􁧍􀝙
* @return mixed
*/
abstract public function query($sql);
/**
* 􀺱􁧃􀥚􁤈􀷄􀴝
* @param string $sql sql􁧍􀝙
* @return array
*/
abstract public function getAll($sql);
/**
* 􀜔􁤈􀷄􀴝
* @param string $sql sql􁧍􀝙
* @return array
*/
abstract public function getRow($sql);
/**
* 􀺱􁧃􀜔􀓻􀷄􀴝 􀦇 count(*)
* @param string $sql sql􁧍􀝙
* @return mixed
*/
abstract public function getOne($sql);
/**
* 􁛔􀛖􀚠􀭌sql􀬚􀲗􁤈
* @param array $data 􀙉􁘶􀷄􁕟 􁲫/􀘀􀓨􁤒􁌱􀚜/􀘀􀩒􀬫
* @param string $table 􁤒􀝷􀨁
* @param string $act 􀛖􀖢/update/insert
* @param string $where 􀹵􀕯,􁊠􀔭update
* @return int 􀷛􀵊􀙁􁌱􁤈􁌱􀔆􁲫􀘀􀱲􀭽􀟥􁤈􀷄
*/

abstract public function Exec($data , $table , $act='insert' , $where='0');
/**
* 􁬬􀢧􀓤􀓞􀹵insert􁧍􀝙􀔾􁊞􁌱􀔆􁲫􀘀
*/
abstract public function lastId();
/**
* 􁬬􀢧􀓤􀓞􀹵􁧍􀝙􀭽􀟥􁌱􁤈􀷄
*/
abstract public function affectRows();
}

class Mysql extends aDB{
	public $link =null;
	public function __construct(){
		$this->conn();
	}
	/**
	 * 连接数据库，从配置文件读取配置信息
	 * //不要把conn()改成construct，因为与抽象类不符合
	 */
	public function conn(){
$cfg= include './config.php';
//var_dump($cfg);
		$this->link = new mysqli($cfg['host'],$cfg['user'],$cfg['password'],$cfg['db']);
//		var_dump($mysqli);
$this->query('set name'.$cfg['charset']);
	}
	public function query($sql){
		return $this->link->query($sql);
	}
	
	
	public function getAll($sql){
		$data=array();
		$res=$this->query($sql);
		while($row =$res->fetch_assoc()){
			$data[]=$row;
		}
		return $data;
//		var_dump($data);
	}
	
	public function getRow($sql){
	$res = $this->query($sql);	
	$row=$res->fetch_assoc();
	return $row;
		
	}
	
	public function getOne($sql){
		$res =$this->query($sql);
		$row =$res->fetch_row()[0];
		return $row;
		
	}
	public function Exec($data , $table , $act='insert' , $where='0'){
		
		if($act=='insert'){
		$sql="insert into ".$table."(";
			$sql.=implode(',', array_keys($data)).") values('";
		$sql.=implode("','", array_values($data))."')";
//		var_dump($sql);
//return $this->query($sql);//insert update delete等返回值是false或者true
		}else{
			//where id=
			$sql = "update $table set ";
			foreach($data as $k=>$v){
				$sql.=$k."='".$v."',";
			}
$sql=rtrim($sql,',').'where '.$where;
//			var_dump($sql);
//			return $this->query($sql);//true或者false
		
		}
		return $this->query($sql);
	}
public function lastId(){
	return $this->link->insert_id;
}
public function affectRows(){
	return $this->link->affected_rows;
}
	
}

$mysql=new Mysql();
//$arr=array('title'=>'shinhwa','content'=>2);
//$a=$mysql->Exec($arr,'art');

$arr=array('title'=>'wa','content'=>'d000');
$a=$mysql->Exec($arr,'art','update','cat_id=8');
//$a=$mysql->Exec($arr,'art');
var_dump($a);
echo $mysql->lastId();
var_dump($mysql->affectRows());

?>