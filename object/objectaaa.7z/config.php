<?php
$cfg = array(
'host'=>'localhost',
'user'=>'root',
'password'=>'root',
'db'=>'blog',
'charset'=>'utf8');
return $cfg;
?>