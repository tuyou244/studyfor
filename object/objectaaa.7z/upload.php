<?php
abstract class aUpload {
public $allowExt = array('jpg' , 'jpeg' , 'png' , 'rar');
public $maxSize = 1; // 􀹋􀥟􀓤􀖃􀥟􀩜,􀕦M􀔅􀜔􀖖
protected $error = ''; // 􁲙􁧏􀗞􀯳
/**
* 􀚓􀺉$_FILES􀓾$name􀤒􁌱􀗞􀯳,􀾲􀖺$_FILES􀓾􁌱['pic']
* @param string $name 􁤒􀜔􀓾file􁤒􀜔􁶱􁌱name􀘀
* @return array 􀓤􀖃􀷈􀕯􁌱􀗞􀯳,􀛱􀞌(tmp_name,oname[􀓧􀞌􀝸􁖗􁌱􀷈􀕯􀝷􁑍] ,
ext[􀝸􁖗],size)
*/
abstract public function getInfo($name);
/**
* 􀚠􀭌􁍓􀭯 􀣁􀭮􀚹􁗑􁒊􁌱􀻑􁍓􀭯􁌱upload􁍓􀭯􀓾,􀳲􀬙/􀹌􀷭 􀚠􀭌􁍓􀭯
* @return string 􁍓􀭯􁪠􀮆 􀖺 /upload/2015/0331
*/
abstract public function createDir();
/**
* 􁊞􀱮􁵋􀹢􀷈􀕯􀝷
* @param int $len 􁵋􀹢􀨁􁒧􀔀􁌱􁳩􀬶
* @return string 􀳰􀨧􁳩􀬶􁌱􁵋􀹢􀨁􁒧􀔀
*/
abstract public function randStr($len = 8);


/**
* 􀓤􀖃􀷈􀕯
* @param string $name 􁤒􀜔􀓾file􁤒􀜔􁶱􁌱name􀘀
* @return string 􀓤􀖃􀷈􀕯􁌱􁪠􀮆,􀕗web􀻑􁍓􀭯􀭏􀦤􁦇,􀦇/upload/2015/0331/a
.jpg
*/
abstract public function up($name);
/*
􀚣􀷙 $_FILES[$name]
􁧣􁊠getInfo 􀚓􀺉􀷈􀕯􁌱􀥟􀩜,􀝸􁖗􁒵
􁧣􁊠checkType
􁧣􁊠checkSize
􁧣􁊠createDir
􁧣􁊠randStr􁊞􀱮􁵋􀹢􀷈􀕯􀝷
􁑏􀛖,􁬬􀢧􁪠􀮆
*/
/**
* 􀼄􁁥􀷈􀕯􁌱􁔄􀣳,􀦇􀝝􀘱􁦜jpg,jpeg,png,rar,􀓧􀘱􁦜exe
* @param $ext 􀷈􀕯􁌱􀝸􁖗
* @return boolean
*/
abstract protected function checkType($ext);
/**
* 􀼄􁁥􀷈􀕯􁌱􀥟􀩜
* @param $size 􀷈􀕯􁌱􀥟􀩜
* @return boolean
*/
abstract protected function checkSize($size);
/**
* 􁧛􀝐􁲙􁧏􀗞􀯳
*/
public function getError() {
return $this->error;
}
}


//echo strrchr('233.jpg.html', '.');


class Upload extends aUpload{
//	public $allowExt = array('jpg' , 'jpeg' , 'png' , 'rar');
//	public $maxSize = 1; 
//protected $error = '';
 public function getInfo($name){
// 	var_dump($_FILES[$name]);
//$file = $_FILES[$name];
//return $file;
return $_FILES[$name];
 }
 
 public function createDir(){
 	$dir='upload/'.date('Y/m/d');
	if(!is_dir($dir)){
		mkdir($dir,0777,true);
	}
	return $dir;//upload
 }
 
 
 public function randStr($len = 8){
 	return substr(md5(time()).mt_rand(1111, 9999), 0,$len);
 }

protected function checkType($ext){
	//win下修改图片后缀名会影响$_FILES中的信息
	return in_array($ext, $this->allowExt);
}
 protected function checkSize($size){
 	return $size<$this->maxSize*1024*1024;
 }
 
 public function up($name){
 	//上传之前需要判断是否有文件传入、文件后缀名、大小
 	//上传时需要createdir.randstr.ext
 	if(!isset($_FILES[$name])){
 		echo '需要传入文件';exit;
 	}
	
	$info=$this->getInfo($name);
$e=ltrim(strrchr($info['name'],'.'),'.');
if(!$this->checkType($e)){
	echo '我要图片';exit;
}


if(!$this->checkSize($info['size'])){
 	echo '图片太大了';exit;
 }

$dir =$this->createDir();
$filename=$this->randStr().'.'.$e;
if(move_uploaded_file($info['tmp_name'],$dir.'/'.$filename)){
	$data['path']=$dir;
	$data['filename']=$filename;
	return $data;
}
 }
 
public function getError() {
return $this->error;
}
}



$upload =new Upload();
var_dump($upload->getInfo('pic'));
$upload->up('pic');
//echo $upload->randStr();

//
//$tt=array(1,2,3);
//var_dump(in_array(4, $tt));//bool(false)

//$upload->up('pic');
?>