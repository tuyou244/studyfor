<?php
//魔术方法，都需要实例化对象，__construct()/__destruct()
//属性名不存在或者不可见
//1.    __get($a)
class zhao{
	public function __get($a){
	echo $a;	
	}
	
	
	public function __set($b,$c){
	echo $b.'-------'.$c;	
	}
	
	public function __isset($d){
	echo $d;	
	}
	public function __unset($d){
	echo $d;	
	}
}

$a=new zhao();
$a->zhubajie;//zhubajie后面没有括号是调用属性的，但类中不存在该属性，所以自动调用__get($a)魔术方法,且$a是属性名//属性不存在或者protected、private时

$a->aqiu='hahha';//为不存在的属性赋值
isset($a->zhang);//当isset或者empty判断属性名是否存在时，自动触发__isset
unset($a->shemeya);








?>