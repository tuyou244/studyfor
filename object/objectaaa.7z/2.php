<?php
/*
//封装数据库的类
class Mysql{
	public $link = null;
	//连接数据库的函数
	public function conn(){
		$cfg = array(
		'host'=>'localhost',
		'user'=>'root',
		'password'=>'root',
		'db'=>'blog',
		'charset'=>'utf8'
		);
		$this->link=mysqli_connect($cfg['host'], $cfg['user'], $cfg['password'], $cfg['db']);
		
	}
	
//执行sql语句
public function query($sql){
	return mysqli_query($this->link, $sql);
}	
	
//获取数据库的数据
public function getAll($sql){
	$rs = $this->query($sql);
	$data = array();
	while($row = mysqli_fetch_assoc($rs)){
		$data[]=$row;
	}
	
	return $data;
}	

}//数据库的类结束

$db = new Mysql();
$db->conn();
$a = $db->getAll('select * from cat');
var_dump($a);
*/

//构造方法
class Human{
	public function __construct(){
		echo '呱呱坠地';
	}
}

$human =new Human();
//析构方法
class junjin{
	public function  __destruct(){
		echo '结束';
	}
}

$des = new junjin();
//不想手动连接
//封装数据库的类
class MYSQL{
	public $link = null;
	//连接数据库的函数
	public function conn(){
		$cfg = array(
		'host'=>'localhost',
		'user'=>'root',
		'password'=>'root',
		'db'=>'blog',
		'charset'=>'utf8'
		);
		$this->link=mysqli_connect($cfg['host'], $cfg['user'], $cfg['password'], $cfg['db']);
		
	}
	//自动连接数据库
	public function __construct(){
		$this->conn();
	}
	
//执行sql语句
public function query($sql){
	return mysqli_query($this->link, $sql);
}	
	
//获取数据库的数据
public function getAll($sql){
	$rs = $this->query($sql);
	$data = array();
	while($row = mysqli_fetch_assoc($rs)){
		$data[]=$row;
	}
	
	return $data;
}	

}//数据库的类结束

$hui = new MYSQL();//自动连接数据库
//$hup=$hui->getAll('select * from art');
//print_r($hup);

class STU{
	public $age=null;
	public $name=null ;
	//不写属性好像也可以
	public function __construct($name,$age){
		echo $this->name=$name;
		echo $this->age=$age;
	}
	
//	public function __construct($name,$age){
//		echo $name,$age;
//	}
}
//$bb = new STU('ll',23);
$bb = new STU('lisi',23);
?>