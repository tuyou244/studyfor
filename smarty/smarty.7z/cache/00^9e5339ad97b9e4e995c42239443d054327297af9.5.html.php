<?php
/* Smarty version 3.1.32, created on 2018-09-07 08:20:46
  from 'D:\Program\phpstudy\PHPTutorial\WWW\smarty\5.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5b9234de257198_86874279',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'cbe00292aad27520d929c8322cd7148fbd10f529' => 
    array (
      0 => 'D:\\Program\\phpstudy\\PHPTutorial\\WWW\\smarty\\5.html',
      1 => 1536306121,
      2 => 'file',
    ),
  ),
  'cache_lifetime' => 5,
),true)) {
function content_5b9234de257198_86874279 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title></title>
	</head>
	<body>
		<p>00</p>
	</body>
</html>
<?php }
}
