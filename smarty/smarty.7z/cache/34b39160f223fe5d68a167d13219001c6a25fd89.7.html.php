<?php
/* Smarty version 3.1.32, created on 2018-09-07 12:45:23
  from 'D:\Program\phpstudy\PHPTutorial\WWW\smarty\7.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5b9272e3430397_40360909',
  'has_nocache_code' => true,
  'file_dependency' => 
  array (
    '71acd41bdfdb326fd44621602c6454c7967783aa' => 
    array (
      0 => 'D:\\Program\\phpstudy\\PHPTutorial\\WWW\\smarty\\7.html',
      1 => 1536310373,
      2 => 'file',
    ),
  ),
  'cache_lifetime' => 5,
),true)) {
function content_5b9272e3430397_40360909 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_checkPlugins(array(0=>array('file'=>'D:\\Program\\phpstudy\\PHPTutorial\\WWW\\smarty\\libs\\plugins\\modifier.date_format.php','function'=>'smarty_modifier_date_format',),));
?><!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title></title>
	</head>
	<body>
		<?php echo $_smarty_tpl->tpl_vars['a']->value;?>

		0000
		<?php echo insert_oo(array (
),$_smarty_tpl);?>		<?php echo smarty_modifier_date_format(time(),'Y-m-d');?>

		<!--不缓存标签-->
	</body>
</html>
<?php }
}
