<?php
require './libs/Smarty.class.php';
$aa=new Smarty;
$aa->caching=true;//开启缓存
$aa->cache_lifetime=5;//重要，缓存时间


//$aa->assign('a','88');//开启缓存后修改数字，刷新不会立刻改变数字，等缓存时间过后才会改变
//$aa->display('5.html');
//有缓存用缓存，没缓存再使用assign和display重新编译//不用缓存的话有时会出错，如刷新会立刻更改
$d='hfs';
$id=$_GET['id'];
if(!$aa->isCached('5.html',$id)){
	$aa->assign('YUO',$id);//$id在HTML页面以及cache的缓存文件中
	echo 7777;
}
//$aa->display('5.html');//如果不加$id,将无法实现5秒缓存效果
$aa->display('5.html',$id);//每修改一次，cache文件夹就产生以改变的参数值开头的新文件
//一开始都没有缓存，设置没缓存时assign填入数据并且编译PHP文件，echo表明没缓存的时候才输出然后再使用display，有缓存时由于caching为true，直接使用display可以实现效果//所以7777在上面，$id在下面，5秒过后刷新只剩下$id
//cache中的缓存文件是可以把结果输出的，template中的文件是编译PHP得到的文件
?>