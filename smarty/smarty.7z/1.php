<?php

class Mini{
	public $data=array();
	
	public function assign($k,$v){
	$this->data[$k]=$v;
	print_r($this->data);//Array ( [title] => 博客名称 ) Array ( [title] => 博客名称 [content] => 猪八戒 )
}
	
	public function tit($file){
	$html=file_get_contents($file);
	print_r($this->data);// Array ( [title] => 博客名称 [content] => 猪八戒 )
	$html=str_replace('{$', "<?php echo \$this->data['", $html);
	$html=str_replace('}', "'];?>", $html);
	$tmp=$file.'.php';
	file_put_contents($tmp, $html);
	return $tmp;
}

public function display($file){
	$file= $this->tit($file);
//	 echo $this->data['title'];
//	 echo $this->data['content'];
	include($file);
}

}
$title='博客名称';
$content='猪八戒';//顺序重要
$mini =new Mini();
$mini->assign('title',$title);
$mini->assign('content',$content);

$mini->display('1.html');
// include($mini->tit('1.html'));
//include(tit('1.html'));

//include '1.html';

?>