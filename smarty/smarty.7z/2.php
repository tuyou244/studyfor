<?php
require './libs/Smarty.class.php';
$sa = new Smarty;

//$sa->template_dir='./dir';
$d='endrelicheri';
$ss=array('age'=>23,'name'=>'lisi');
$sa->assign('title',$d);
$sa->assign('arr',$ss);
$sa->left_delimiter='<{';
$sa->right_delimiter='}>';


class a{
	public $a='geis';
	
}
$qa=new a();
$sa->assign('qa',$qa);

$sa->display('2.html');//必须最后
?>