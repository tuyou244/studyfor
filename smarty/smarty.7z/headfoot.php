
<?php
require './libs/Smarty.class.php';
$sm=new Smarty;
$sm->assign('k','bbblll');
$sm->display('headfoot.html');
//echo $sm->fetch('4.html');//很少用
?>
