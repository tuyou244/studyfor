<?php
//session_start();
//print_r($_SESSION);

print_r($_COOKIE);
?>