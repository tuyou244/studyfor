<?php

//session_start();
//$_SESSION['name']='li';
//$_SESSION['age']=24;

setcookie('wang','666');


?>