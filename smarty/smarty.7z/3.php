<?php
require './libs/Smarty.class.php';
$sa = new Smarty;
$n=mt_rand(1,10);

$sa->assign('n',$n);//不加左边界右边界符变成  <10>之类的，最好不要在HTML中修改边界符，最好在PHP添加边界符的限制
//$sa->left_delimiter='<{';
//$sa->right_delimiter='}>';


$h=array(
array('id'=>1,'title'=>'睡着了？'),
array('id'=>2,'title'=>'睡着mei'),
array('id'=>3,'title'=>'you睡着了')
);
$sa->assign('h',$h);
$sa->display('3.html');
?>