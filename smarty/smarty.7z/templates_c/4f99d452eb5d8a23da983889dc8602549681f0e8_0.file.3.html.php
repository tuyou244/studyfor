<?php
/* Smarty version 3.1.32, created on 2018-09-07 08:24:39
  from 'D:\Program\phpstudy\PHPTutorial\WWW\smarty\3.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5b9235c7990230_23970712',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '4f99d452eb5d8a23da983889dc8602549681f0e8' => 
    array (
      0 => 'D:\\Program\\phpstudy\\PHPTutorial\\WWW\\smarty\\3.html',
      1 => 1536294150,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5b9235c7990230_23970712 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title></title>
	</head>
	<body>
		<h3>
			<?php if ($_smarty_tpl->tpl_vars['n']->value == 4) {?>你好
			<?php } else {
$_prefixVariable1 = 5;
$_smarty_tpl->_assignInScope('n', $_prefixVariable1);
if ($_prefixVariable1) {?>行吧
			<?php } else { ?>知道了
		<?php }}?>
		</h3>
		<h2>
			<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['h']->value, 'v', false, 'k');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['k']->value => $_smarty_tpl->tpl_vars['v']->value) {
?>
			<?php echo $_smarty_tpl->tpl_vars['v']->value['id']+2;?>

			<?php echo $_smarty_tpl->tpl_vars['v']->value['title'];?>

			<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
			
		</h2>
	</body>
</html>
<?php }
}
