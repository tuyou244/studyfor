<?php
/* Smarty version 3.1.32, created on 2018-09-07 07:42:03
  from 'D:\Program\phpstudy\PHPTutorial\WWW\smarty\5.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5b922bcbdf4715_06793884',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'cbe00292aad27520d929c8322cd7148fbd10f529' => 
    array (
      0 => 'D:\\Program\\phpstudy\\PHPTutorial\\WWW\\smarty\\5.html',
      1 => 1536306121,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5b922bcbdf4715_06793884 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->compiled->nocache_hash = '21223789865b922bcbda6500_53067177';
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title></title>
	</head>
	<body>
		<p><?php echo $_smarty_tpl->tpl_vars['YUO']->value;?>
</p>
	</body>
</html>
<?php }
}
