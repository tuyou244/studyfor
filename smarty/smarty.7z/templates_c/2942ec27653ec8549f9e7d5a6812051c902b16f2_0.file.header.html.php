<?php
/* Smarty version 3.1.32, created on 2018-09-07 12:44:35
  from 'D:\Program\phpstudy\PHPTutorial\WWW\smarty\header.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5b9272b3d49794_53857793',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '2942ec27653ec8549f9e7d5a6812051c902b16f2' => 
    array (
      0 => 'D:\\Program\\phpstudy\\PHPTutorial\\WWW\\smarty\\header.html',
      1 => 1536296582,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5b9272b3d49794_53857793 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title></title>
	</head>
	<body>
	我是头部<?php }
}
