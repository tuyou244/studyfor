<?php
/* Smarty version 3.1.32, created on 2018-09-07 09:35:21
  from 'D:\Program\phpstudy\PHPTutorial\WWW\smarty\smartyandMVC.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5b924659aa40c7_74525792',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '96976206f3e4bb38e89f48ed7f5873cec8af08ff' => 
    array (
      0 => 'D:\\Program\\phpstudy\\PHPTutorial\\WWW\\smarty\\smartyandMVC.html',
      1 => 1536312920,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5b924659aa40c7_74525792 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title></title>
	</head>
	<body>
		<?php echo $_smarty_tpl->tpl_vars['ss']->value;?>

	</body>
</html>
<?php }
}
