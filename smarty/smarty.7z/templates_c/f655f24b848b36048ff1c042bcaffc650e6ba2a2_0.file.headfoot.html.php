<?php
/* Smarty version 3.1.32, created on 2018-09-07 12:44:35
  from 'D:\Program\phpstudy\PHPTutorial\WWW\smarty\headfoot.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5b9272b3d32098_72944275',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'f655f24b848b36048ff1c042bcaffc650e6ba2a2' => 
    array (
      0 => 'D:\\Program\\phpstudy\\PHPTutorial\\WWW\\smarty\\headfoot.html',
      1 => 1536296776,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.html' => 1,
    'file:footer.html' => 1,
  ),
),false)) {
function content_5b9272b3d32098_72944275 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_checkPlugins(array(0=>array('file'=>'D:\\Program\\phpstudy\\PHPTutorial\\WWW\\smarty\\libs\\plugins\\modifier.date_format.php','function'=>'smarty_modifier_date_format',),));
$_smarty_tpl->_subTemplateRender('file:header.html', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>


<p><?php echo mb_strtoupper($_smarty_tpl->tpl_vars['k']->value, 'UTF-8');?>
</p>
		<!--变量调节器 变为全大写-->
		<p><?php echo smarty_modifier_date_format(time(),'Y-m-d h:m:s');?>
</p>
		<!--加不加%都可以，最好加上-->
<?php $_smarty_tpl->_subTemplateRender('file:footer.html', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
<!--必须使用include-->
<?php }
}
