<?php /* Smarty version 3.1.32, created on 2018-09-07 07:45:10
         compiled from 'D:\Program\phpstudy\PHPTutorial\WWW\smarty\config.conf' */ ?>
<?php
/* Smarty version 3.1.32, created on 2018-09-07 07:45:10
  from 'D:\Program\phpstudy\PHPTutorial\WWW\smarty\config.conf' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5b922c8698e307_19486719',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '3047f34e1d5da6fc9aed845065a3e9aa8ccb9f73' => 
    array (
      0 => 'D:\\Program\\phpstudy\\PHPTutorial\\WWW\\smarty\\config.conf',
      1 => 1536292155,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5b922c8698e307_19486719 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->smarty->ext->configLoad->_loadConfigVars($_smarty_tpl, array (
  'sections' => 
  array (
  ),
  'vars' => 
  array (
    'xxx' => 123,
    'name' => 'wangqian',
    'age' => 45,
  ),
));
}
}
