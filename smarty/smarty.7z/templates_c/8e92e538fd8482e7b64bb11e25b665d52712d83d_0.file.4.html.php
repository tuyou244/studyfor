<?php
/* Smarty version 3.1.32, created on 2018-09-07 08:24:35
  from 'D:\Program\phpstudy\PHPTutorial\WWW\smarty\4.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5b9235c3e98617_92826968',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '8e92e538fd8482e7b64bb11e25b665d52712d83d' => 
    array (
      0 => 'D:\\Program\\phpstudy\\PHPTutorial\\WWW\\smarty\\4.html',
      1 => 1536295467,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5b9235c3e98617_92826968 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_checkPlugins(array(0=>array('file'=>'D:\\Program\\phpstudy\\PHPTutorial\\WWW\\smarty\\libs\\plugins\\modifier.date_format.php','function'=>'smarty_modifier_date_format',),));
?><!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title></title>
	</head>
	<body>
		
		
		<p><?php echo mb_strtoupper($_smarty_tpl->tpl_vars['k']->value, 'UTF-8');?>
</p>
		<!--变量调节器 变为全大写-->
		<p><?php echo smarty_modifier_date_format(time(),'Y-m-d h:m:s');?>
</p>
		<!--加不加%都可以，最好加上-->
	</body>
</html>
<?php }
}
