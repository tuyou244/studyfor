<?php
/* Smarty version 3.1.32, created on 2018-09-07 12:44:35
  from 'D:\Program\phpstudy\PHPTutorial\WWW\smarty\footer.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5b9272b3d60ea1_36788671',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '6b02a910b08d2fdc99aca82665f092e9db9b6905' => 
    array (
      0 => 'D:\\Program\\phpstudy\\PHPTutorial\\WWW\\smarty\\footer.html',
      1 => 1536296573,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5b9272b3d60ea1_36788671 (Smarty_Internal_Template $_smarty_tpl) {
?>臭脚丫子
	</body>
</html>
<?php }
}
