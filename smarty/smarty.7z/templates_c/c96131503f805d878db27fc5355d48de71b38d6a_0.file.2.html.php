<?php
/* Smarty version 3.1.32, created on 2018-09-07 12:55:13
  from 'D:\Program\phpstudy\PHPTutorial\WWW\smarty\2.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5b927531be4006_46201986',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'c96131503f805d878db27fc5355d48de71b38d6a' => 
    array (
      0 => 'D:\\Program\\phpstudy\\PHPTutorial\\WWW\\smarty\\2.html',
      1 => 1536324911,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5b927531be4006_46201986 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title></title>
	</head>
	<body>
		<?php
$_smarty_tpl->smarty->ext->configLoad->_loadConfigFile($_smarty_tpl, 'config.conf', null, 0);
?>

		<h3><?php echo $_smarty_tpl->smarty->ext->configload->_getConfigVariable($_smarty_tpl, 'xxx');?>
</h3>
		<h2><?php echo $_smarty_tpl->tpl_vars['title']->value;?>
</h2>
		<p><?php echo $_smarty_tpl->tpl_vars['arr']->value['name'];?>
</p>
		<p><?php echo $_smarty_tpl->tpl_vars['arr']->value['age'];?>
</p>
		<p><?php echo $_smarty_tpl->tpl_vars['qa']->value->a;?>
</p>
	<h3><?php echo time();?>
</h3>
	<h3><?php echo $_GET['key'];?>
</h3>
	<h3><?php echo @constant('EEE');?>
</h3>
	
	</body>
</html>
<?php }
}
