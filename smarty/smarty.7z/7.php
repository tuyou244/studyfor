<?php
require './libs/Smarty.class.php';
$a=new Smarty;
$a->caching=true;
$a->cache_lifetime=5;

function insert_oo(){
	echo 'woshizuibangde';
}//模板调用PHP的函数，不缓存

$a->assign('a','annn',true);//不缓存，适用于单标签
$a->assign('b','0000');
$a->display('7.html');
//效果：cache文件夹的文件都是直接呈现结果，如果不缓存即和template文件夹的文件效果一样是PHP代码
//{nocache}{$smarty.now|date_format:'Y-m-d'}{/nocache}
//		<!--不缓存标签-->

//不缓存一共3种方法
?>