<?php
require './libs/Smarty.class.php';
$rr=new Smarty;
 
 $a=$_GET['a'];
 $b=$_GET['b'];
 
 function add($a,$b){
 	
	
	
 	if(!empty($a)&&!empty($b)){//逻辑判断为c层
 		
		
		
 		return $a+$b;//数据处理为M层
 		//smartyandMVC.html为v层
 	}
 }
 
 $c=add($a,$b);
 $rr->assign('ss',$c);
 $rr->display('smartyandMVC.html');
 
 //MVC与smarty没关系，MVC就是一种思想，smarty就是一种工具
 //MVC不以文件区分，而是以代码的实现功能类型的不同区分的。可以往数据库添加数据，进行数学运算就是属于M层;逻辑判断获取地址栏数据foreach等属于C层;只负责展示的就是V层。
?>