<?php
require './libs/Smarty.class.php';
$sm=new Smarty;
$sm->assign('k','SDfgSjh');
$sm->display('4.html');
//echo $sm->fetch('4.html');//很少用
?>