<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title></title>
	</head>
	<body>
		<!--<p><?php echo $title;?></p>
			<h1><?php echo $content;?></h1>-->
			<p><?php echo $this->data['title'];?></p>
			<h1><?php echo $this->data['content'];?></h1>
	</body>
</html>
