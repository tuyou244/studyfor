<?php
require './libs/Smarty.class.php';
$aa=new Smarty;
$aa->caching=true;//开启缓存
$aa->cache_lifetime=5;//重要，缓存时间


//$aa->assign('a','88');//开启缓存后修改数字，刷新不会立刻改变数字，等缓存时间过后才会改变
//$aa->display('5.html');
//有缓存用缓存，没缓存再使用assign和display重新编译//不用缓存的话有时会出错，如刷新会立刻更改
$d='hhhh';
if(!$aa->isCached('5.html')){
	$aa->assign('YUO',$d);
	echo 666;
}
$aa->display('5.html');
//一开始都没有缓存，设置没缓存时assign填入数据并且编译PHP文件，echo表明没缓存的时候才输出然后再使用display，有缓存时由于caching为true，直接使用display可以实现效果
//cache中的缓存文件是可以把结果输出的，template中的文件是编译PHP得到的文件
//只要开启缓存在cache文件夹就有文件
//甚至设置参数可以有多个缓存文件，不设置只能在原文件的基础上改变值
?>